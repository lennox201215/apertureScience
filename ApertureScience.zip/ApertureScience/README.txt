To Execute this FILE
You Need To open The terminal in the Folder 
You Need python just python
The command is
if you just open the file at the end will close is thats why you open it in cmd

python3 aperturescience.py

Thank You For Trying My Project