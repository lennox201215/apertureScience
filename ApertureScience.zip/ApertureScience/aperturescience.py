def aperture_science_logo(): 
    logo = r"""
              .,-:;//;:=,
          . :H@@@MM@M#H/.,+%;,
       ,/X+ +M@@M@MM%=,-%HMMM@X/,
     -+@MM; $M@@MH+-,;XMMMM@MMMM@+-
    ;@M@@M- XM@X;. -+XXXXXHHH@M@M#@/.
  ,%MM@@MH ,@%=             .---=-=:=,.
  =@#@@@MX.,                -%HX$$%%%:;
 =-./@M@M$                   .;@MMMM@MM:
 X@/ -$MM/                    . +MM@@@M$
,@M@H: :@:                    . =X#@@@@-
,@@@MMX, .                    /H- ;@M@M=
.H@@@@M@+,                    %MM+..%#$.
 /MMMM@MMH/.                  XM@MH; =;
  /%+%$XHH@$=              , .H@@@@MX,
   .=--------.           -%H.,@@@@@MX,
   .%MM@@@HHHXX$$$%+- .:$MMX =M@@MM%.
     =XMMM@MM@MM#H;,-+HMM@M+ /MMMX=
       =%@M@M#@$-.=$@MM@@@M; %M%=
         ,:+$+-,/H#MMMMMMM@= =,
              =++%%%%+/:-.
    """
    print(logo)

aperture_science_logo()
print("Glados system 1.2 Startup Disable Security Starting Up lab")

print("--. .-.. .- -.. --- ... / .--. .- ... ... .-- --- .-. - ---... .--. --- .-. - .- .-.. ..--- / --. .-.. .- -.. --- ... / ..- ... . .-. ---... -... .- -.-. -.- ..- .--.")

print("Welcome To Glados OS")

print("There Are No Commands But..... BUT STILL DONT LOOK AT THE CODE IF YOU LOOK YOURE NOT A REAL APERTURE SCIENCE EMPLOYEE ")

def login_system():
    USERNAME = "glados"
    PASSWORD = "portal0"

    print("=== APERTURE SCIENCE TERMINAL ===")
    user = input("User: ")
    pwd = input("Password: ")

    if user == USERNAME and pwd == PASSWORD:
        print("\nAccess Granted.\n")
        print("GLaDOS ONLINE")
        print("Welcome to the Aperture Science Computer-Aided Enrichment Center.")
        print("Please remain calm. This message confirms your login was a success.")
    else:
        print("\nAccess Denied.")
        print("Unauthorized user detected.")

login_system()

print("Welcome in Glados System")

choice = input("DO YOU WANNA SHUTDOWN GLADOS (yes/no): ").strip().lower()

if choice == "yes":
    aperture_science_logo()
    print("\n[Aperture Science]")
    print("Glados is Shutting Down.")
    print("Activating neurotoxic")
    print("[GLADOS]HAHA HUMAN YOU THINK YOU CAN SHUTDOWM ME HAHAHA.")
elif choice == "no":
    print("\n[Aperture Science]")
    print("glados stays online.")
    print("[GLADOS]Thank You Human For Staying Me Online But Still The Cake Is A Lie.")
    
else:
    print("\nInvalid input. Please restart and type 'yes' or 'no'.")

print("[GLADOS]Hello Human You Think how Can i Talk To you Becuse i Cant This Is the End bye HUMAN NEVER RUN THIS AGAIN IF YOU RUN THIS AGAIN YOU WILL SEE THE SAME MESSAGE bye bye")